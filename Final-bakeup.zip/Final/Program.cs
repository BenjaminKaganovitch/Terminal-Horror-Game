﻿namespace Final
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Game myGame = new Game();
            myGame.GetMenuOption();










        }
    }
}